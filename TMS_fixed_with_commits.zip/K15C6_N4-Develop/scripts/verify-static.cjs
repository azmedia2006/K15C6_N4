'use strict';

// Fast, dependency-free checks that can run before installing backend packages.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const ignoredDirectories = new Set(['node_modules', '.git', 'target', 'dist', 'build']);
const problems = [];
const javascriptFiles = [];

function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(fullPath);
    else if (entry.isFile() && entry.name.endsWith('.js') && !fullPath.includes(`${path.sep}kn72${path.sep}`)) {
      javascriptFiles.push(fullPath);
    }
  }
}

walk(root);
for (const file of javascriptFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    problems.push(`Cú pháp JavaScript lỗi: ${path.relative(root, file)}\n${result.stderr || result.stdout}`);
  }
}

for (const packagePath of ['package.json', 'backend/package.json']) {
  const absolutePath = path.join(root, packagePath);
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(absolutePath, 'utf8'));
  } catch (error) {
    problems.push(`Không đọc được ${packagePath}: ${error.message}`);
    continue;
  }

  for (const [scriptName, command] of Object.entries(manifest.scripts || {})) {
    const match = command.match(/(?:node(?:\s+--test)?\s+)test\/([^\s]+)/);
    if (!match) continue;
    const testPath = path.join(path.dirname(absolutePath), 'test', match[1]);
    if (!fs.existsSync(testPath)) problems.push(`Script ${packagePath}#${scriptName} trỏ tới test không tồn tại: ${match[1]}`);
  }
}

const gitignorePath = path.join(root, '.gitignore');
const gitignore = fs.existsSync(gitignorePath) ? fs.readFileSync(gitignorePath, 'utf8') : '';
for (const requiredEntry of ['.env', 'node_modules/', 'backend/data/']) {
  if (!gitignore.split(/\r?\n/).some(line => line.trim() === requiredEntry)) {
    problems.push(`.gitignore cần có mục ${requiredEntry} để tránh đưa dữ liệu/secret vào Git.`);
  }
}

if (problems.length) {
  console.error(`STATIC CHECK FAILED (${problems.length} vấn đề)`);
  for (const problem of problems) console.error(`\n- ${problem}`);
  process.exitCode = 1;
} else {
  console.log(`STATIC CHECK PASSED: ${javascriptFiles.length} tệp JavaScript hợp lệ; scripts kiểm thử tồn tại; quy tắc bỏ qua secret/dữ liệu được xác nhận.`);
}
