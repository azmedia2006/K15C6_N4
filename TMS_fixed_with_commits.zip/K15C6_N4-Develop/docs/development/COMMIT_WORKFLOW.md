# Quy trình commit TMS

Mục tiêu là tạo lịch sử Git có thể rà soát: mỗi commit nên đại diện cho một thay đổi nhỏ, chạy được và có thông điệp mô tả đúng nội dung. Không tạo commit rỗng hoặc chia một thay đổi duy nhất thành nhiều commit giả chỉ để tăng số lượng.

## Trước mỗi commit

```bash
npm run verify:static
 git status --short
 git diff --check
```

Khi đã cài thư viện backend, chạy bài kiểm thử phù hợp với phần vừa sửa, ví dụ:

```bash
npm run test:kn156
npm run test:kn10
npm run test:final
```

## Quy ước thông điệp

- `feat(scope): ...` — thêm nghiệp vụ hoặc khả năng mới.
- `fix(scope): ...` — sửa lỗi đã xác định.
- `test(scope): ...` — thêm hoặc chỉnh kiểm thử.
- `docs(scope): ...` — tài liệu và hướng dẫn.
- `refactor(scope): ...` — cấu trúc lại mà không đổi hành vi dự kiến.
- `chore(scope): ...` — cấu hình hoặc bảo trì công cụ.

## Ví dụ nhóm commit cho TMS

1. `fix(security): align clickjacking headers across deployments`
2. `chore(quality): add dependency-free static verification`
3. `docs(git): document atomic commit workflow`

Chỉ giữ các commit tương ứng với thay đổi thật sự có trong diff. Trước khi push, kiểm tra `.env`, dữ liệu `backend/data/`, token, mật khẩu và file build không nằm trong staged changes.
